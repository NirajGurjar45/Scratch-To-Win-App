<?php
error_reporting(0);
$host='localhost';   //mainly localhost accepted in major cases but if needed change it with your host
$user='mywallpa_tested1';  // change it with your database user
$password='mywallpa_tested1';  // change it with your database password
$db='mywallpa_tested';   // change it with your database name

$conn=mysqli_connect($host,$user,$password,$db);

?>