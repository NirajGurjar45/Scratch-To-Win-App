<?php 
$demo=true;
?>